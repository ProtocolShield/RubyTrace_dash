const fs = require("fs");

const filePath = "./Data/books.json";







const lendBook = (title, author, borrower, dueDate, category) => {
   
    const b = loadBooks();

    b.push({ title, author, borrower, dueDate, category });

    saveBooks(b);

    return "Book added successfully!";
};

const loadBooks = () => {
    if (fs.existsSync(filePath))
         {
        const data = fs.readFileSync(filePath);

        return JSON.parse(data);
    }

    return [];
};


const saveBooks = (books) => {

    fs.writeFileSync(filePath, JSON.stringify(books, null, 2));
};


const viewBooks = (filter = {}) => {
    
   

    

    let b = loadBooks();

    if (filter.borrower) 
      {
        b = b.filter(book => book.borrower === filter.borrower);
    }

    if (filter.category)
        {
           b = b.filter(book => book.category === filter.category);
       }

    return b;
};



module.exports = { lendBook, viewBooks };
